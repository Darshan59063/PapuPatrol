
# print("hello I am darshan")
# abra k dabra gili gili chu
# Mutable = Can change
# Immutable = Cannot change

# list1 = ["Harry", "Larry", "Carry", "Marie"]
#
# for k in list1:
#     print(k)


l = [darshan , anil , more]

print(l.__len__())
l.in